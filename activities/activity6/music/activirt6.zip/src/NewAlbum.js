import React from 'react';

const NewAlbum = () => {
    return <div>This is a mew album</div>
};

export default NewAlbum;